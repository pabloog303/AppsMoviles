package com.example.examen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import com.example.examen.ui.theme.ExamenTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        val sampleProduct = Product(
            name = "Fender stratocaster",
            price = 4999.99,
            description = "Pastilla humbuker en el punte cuenta con 22 trastres tiene puente flotante .",
            category = "Instrumentos",
            inStock = false,
            relatedProducts = listOf("Cable", "Estuche", "Cuerdas")
        )

        setContent {
            ExamenTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    ProductDetail(product = sampleProduct)
                }
            }
        }
    }
}
