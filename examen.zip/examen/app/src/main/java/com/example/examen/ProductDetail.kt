package com.example.examen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

data class Product(
    val name: String,
    val price: Double,
    val description: String,
    val category: String,
    val inStock: Boolean,
    val relatedProducts: List<String>
)

@Composable
fun ProductDetail(product: Product) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF01579B)) // Cambiado para que coincida con el color del Card
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .width(320.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFB3E5FC))
        ) {
            Column(modifier = Modifier.padding(80.dp)) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = Color(0xFF01579B),
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "$${product.price} MXN",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = Color(0xFF0288D1),
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Categoría: ${product.category}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color(0xFF0277BD)
                    )
                )
                Text(
                    text = product.description,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color(0xFF01579B)
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (product.inStock) {
                        Icon(
                            Icons.Filled.Check,
                            contentDescription = "Disponible",
                            tint = Color(0xFF00796B)
                        )
                        Text(
                            "Disponible",
                            color = Color(0xFF00796B),
                            modifier = Modifier.padding(start = 4.dp),
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = "Agotado",
                            tint = Color(0xFFD32F2F)
                        )
                        Text(
                            "Agotado",
                            color = Color(0xFFD32F2F),
                            modifier = Modifier.padding(start = 4.dp),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = Color(0xFF81D4FA), thickness = 1.dp)
                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    "Productos Relacionados:",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color(0xFF0288D1),
                        fontWeight = FontWeight.Bold
                    )
                )

                if (product.relatedProducts.isNotEmpty()) {
                    LazyColumn {
                        items(product.relatedProducts) { item ->
                            Text(
                                "- $item",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFF01579B)
                                )
                            )
                        }
                    }
                } else {
                    Text(
                        "Sin productos relacionados",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFF01579B)
                        )
                    )
                }
            }
        }
    }
}
